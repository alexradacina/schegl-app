<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>Route Assignments</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="downloadRoutePlan" :disabled="isDownloading">
            <ion-icon :icon="downloadOutline" />
          </ion-button>
          <ion-button @click="refreshAssignments">
            <ion-icon :icon="refreshOutline" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content :fullscreen="true">
      <!-- Compact Date Range Filter -->
      <div class="date-filter-container">
        <ion-segment v-model="dateRangeType" @ionChange="onDateRangeTypeChange">
          <ion-segment-button value="week">
            <ion-label>This Week</ion-label>
          </ion-segment-button>
          <ion-segment-button value="custom">
            <ion-label>Custom Range</ion-label>
          </ion-segment-button>
        </ion-segment>

        <div v-if="dateRangeType === 'custom'" class="custom-date-range">
          <div class="date-picker-group">
            <ion-label>From:</ion-label>
            <ion-datetime-button
                datetime="from-datetime"
                class="date-button"
            ></ion-datetime-button>
            <ion-modal :keep-contents-mounted="true">
              <ion-datetime
                  id="from-datetime"
                  presentation="date"
                  :value="dateRange.from"
                  :max="maxDate"
                  :min="minDate"
                  @ionChange="onFromDateChange"
              ></ion-datetime>
            </ion-modal>
          </div>

          <div class="date-picker-group">
            <ion-label>To:</ion-label>
            <ion-datetime-button
                datetime="to-datetime"
                class="date-button"
            ></ion-datetime-button>
            <ion-modal :keep-contents-mounted="true">
              <ion-datetime
                  id="to-datetime"
                  presentation="date"
                  :value="dateRange.to"
                  :max="maxDate"
                  :min="minDate"
                  @ionChange="onToDateChange"
              ></ion-datetime>
            </ion-modal>
          </div>
        </div>

        <div v-else class="week-display">
          <ion-chip color="primary" outline>
            <ion-icon :icon="calendarOutline"></ion-icon>
            <ion-label>{{ formatWeekRange() }}</ion-label>
          </ion-chip>
        </div>
      </div>

      <ion-refresher slot="fixed" @ionRefresh="handleRefresh">
        <ion-refresher-content></ion-refresher-content>
      </ion-refresher>

      <div v-if="assignmentsStore.isLoading && assignmentsStore.assignments.length === 0" class="loading-container">
        <ion-spinner name="crescent"></ion-spinner>
        <p>Loading assignments...</p>
      </div>

      <div v-else-if="assignmentsStore.assignments.length === 0" class="empty-state">
        <ion-icon :icon="listOutline" size="large" color="medium"></ion-icon>
        <h2>No Assignments</h2>
        <p>You don't have any route assignments for the selected period.</p>
      </div>

      <!-- Grouped Assignments by Date -->
      <div v-else>
        <div v-for="(dayGroup, date) in groupedAssignments" :key="date" class="day-group">
          <!-- Day Header -->
          <div class="day-header">
            <div class="day-info">
              <h2>{{ formatDayHeader(date) }}</h2>
              <ion-chip color="light" size="small">
                {{ dayGroup.assignments.length }} assignment{{ dayGroup.assignments.length !== 1 ? 's' : '' }}
              </ion-chip>
            </div>
            <div class="day-date">
              {{ formatFullDate(date) }}
            </div>
          </div>

          <!-- Route Messages for this day -->
          <div v-if="dayGroup.messages.length > 0" class="day-messages">
            <div class="messages-header">
              <ion-icon :icon="chatbubbleEllipsesOutline" />
              <span>Messages for {{ formatDayHeader(date) }}</span>
            </div>
            <div class="messages-list">
              <div v-for="message in dayGroup.messages" :key="message.id" class="message-item">
                <div class="message-content">
                  <p>{{ message.message }}</p>
                  <small class="message-time">{{ formatMessageTime(message.created_at) }}</small>
                </div>
                <ion-chip v-if="message.type" :color="getMessageTypeColor(message.type)" size="small">
                  {{ message.type }}
                </ion-chip>
              </div>
            </div>
          </div>

          <!-- Assignments for this day -->
          <ion-list class="day-assignments">
            <ion-item
                v-for="assignment in dayGroup.assignments"
                :key="assignment.id"
                button
                @click="viewAssignment(assignment.id)"
            >
              <div class="assignment-content">
                <div class="assignment-header">
                  <h3>{{ assignment.order?.customer?.name || 'No Customer' }}</h3>
                  <div class="header-badges">
                    <ion-badge :color="getStatusColor(assignment.status)">
                      {{ assignment.status || 'unclear' }}
                    </ion-badge>
                  </div>
                </div>
                <div class="assignment-details">
                  <p class="address" v-if="assignment.address">
                    {{ assignment.address.street }}, {{ assignment.address.city }}
                  </p>
                  <p class="order-number" v-if="assignment.order">
                    Order: {{ assignment.order.order_number || assignment.order.id }}
                  </p>
                  <div class="assignment-meta">
                    <p class="items-count">
                      Items: {{ assignment.number_of_items || 0 }}
                    </p>
                    <p class="assignment-time" v-if="assignment.scheduled_time">
                      Time: {{ formatTime(assignment.scheduled_time) }}
                    </p>
                  </div>
                </div>
              </div>
            </ion-item>
          </ion-list>
        </div>
      </div>

      <ion-toast
          :is-open="showToast"
          :message="toastMessage"
          :duration="3000"
          @didDismiss="showToast = false"
      ></ion-toast>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonList,
  IonItem,
  IonIcon,
  IonSpinner,
  IonRefresher,
  IonRefresherContent,
  IonButtons,
  IonButton,
  IonBadge,
  IonToast,
  IonChip,
  IonLabel,
  IonDatetime,
  IonDatetimeButton,
  IonSegment,
  IonSegmentButton,
  IonModal,
} from '@ionic/vue'
import {
  listOutline,
  refreshOutline,
  chevronForwardOutline,
  chatbubbleEllipsesOutline,
  calendarOutline,
  downloadOutline
} from 'ionicons/icons'
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAssignmentsStore } from '@/stores/assignments'
import { useOfflineStorage } from '@/composables/useOfflineStorage'

const router = useRouter()
const assignmentsStore = useAssignmentsStore()
const { saveOfflineFile } = useOfflineStorage()

const showToast = ref(false)
const toastMessage = ref('')
const dateRangeType = ref('week')
const isDownloading = ref(false)

// Get current week dates
const getCurrentWeek = () => {
  const today = new Date()
  const currentDay = today.getDay()
  const startOfWeek = new Date(today)
  startOfWeek.setDate(today.getDate() - currentDay + 1) // Monday

  const endOfWeek = new Date(startOfWeek)
  endOfWeek.setDate(startOfWeek.getDate() + 6) // Sunday

  return {
    from: startOfWeek.toISOString().split('T')[0],
    to: endOfWeek.toISOString().split('T')[0]
  }
}

const dateRange = ref(getCurrentWeek())

// Date constraints
const today = new Date()
const minDate = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate()).toISOString()
const maxDate = new Date(today.getFullYear() + 1, today.getMonth(), today.getDate()).toISOString()

// Group assignments and messages by date
const groupedAssignments = computed(() => {
  const groups: Record<string, { assignments: any[], messages: any[] }> = {}

  // Group assignments by date
  assignmentsStore.assignments.forEach(assignment => {
    const date = assignment.date
    if (!groups[date]) {
      groups[date] = { assignments: [], messages: [] }
    }
    groups[date].assignments.push(assignment)
  })

  // Group messages by date
  assignmentsStore.routeMessages.forEach(message => {
    const messageDate = message.created_at.split('T')[0] // Extract date part
    if (groups[messageDate]) {
      groups[messageDate].messages.push(message)
    }
  })

  // Sort by date
  const sortedGroups: Record<string, { assignments: any[], messages: any[] }> = {}
  Object.keys(groups)
      .sort((a, b) => new Date(a).getTime() - new Date(b).getTime())
      .forEach(date => {
        sortedGroups[date] = groups[date]
        // Sort assignments within each day by scheduled_time
        sortedGroups[date].assignments.sort((a, b) => {
          if (!a.scheduled_time && !b.scheduled_time) return 0
          if (!a.scheduled_time) return 1
          if (!b.scheduled_time) return -1
          return a.scheduled_time.localeCompare(b.scheduled_time)
        })
      })

  return sortedGroups
})

const getStatusColor = (status: string) => {
  if (!status) return 'medium'

  switch (status.toLowerCase()) {
    case 'pending':
      return 'warning'
    case 'in_progress':
      return 'primary'
    case 'completed':
      return 'success'
    case 'cancelled':
      return 'danger'
    case 'unclear':
      return 'medium'
    default:
      return 'medium'
  }
}

const getMessageTypeColor = (type: string) => {
  switch (type?.toLowerCase()) {
    case 'urgent':
      return 'danger'
    case 'warning':
      return 'warning'
    case 'info':
      return 'primary'
    default:
      return 'medium'
  }
}

const formatMessageTime = (timestamp: string) => {
  const date = new Date(timestamp)
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  })
}

const formatDayHeader = (dateString: string) => {
  const date = new Date(dateString)
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)
  const yesterday = new Date(today)
  yesterday.setDate(yesterday.getDate() - 1)

  // Check if it's today
  if (date.toDateString() === today.toDateString()) {
    return 'Today'
  }

  // Check if it's tomorrow
  if (date.toDateString() === tomorrow.toDateString()) {
    return 'Tomorrow'
  }

  // Check if it's yesterday
  if (date.toDateString() === yesterday.toDateString()) {
    return 'Yesterday'
  }

  // Return day of week
  return date.toLocaleDateString('en-US', { weekday: 'long' })
}

const formatFullDate = (dateString: string) => {
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  })
}

const formatWeekRange = () => {
  const fromDate = new Date(dateRange.value.from)
  const toDate = new Date(dateRange.value.to)

  const fromFormatted = fromDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  const toFormatted = toDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })

  return `${fromFormatted} - ${toFormatted}`
}

const formatTime = (timeString: string) => {
  if (!timeString) return ''

  try {
    const time = new Date(`2000-01-01T${timeString}`)
    return time.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    })
  } catch (error) {
    return timeString
  }
}

const viewAssignment = (id: number) => {
  router.push(`/tabs/assignments/${id}`)
}

const onDateRangeTypeChange = (event: any) => {
  dateRangeType.value = event.detail.value

  if (dateRangeType.value === 'week') {
    dateRange.value = getCurrentWeek()
    refreshAssignments()
  }
}

const onFromDateChange = (event: any) => {
  const selectedDate = event.detail.value.split('T')[0]
  dateRange.value.from = selectedDate

  // Ensure 'to' date is not before 'from' date
  if (new Date(dateRange.value.to) < new Date(selectedDate)) {
    dateRange.value.to = selectedDate
  }

  refreshAssignments()
}

const onToDateChange = (event: any) => {
  const selectedDate = event.detail.value.split('T')[0]
  dateRange.value.to = selectedDate

  // Ensure 'from' date is not after 'to' date
  if (new Date(dateRange.value.from) > new Date(selectedDate)) {
    dateRange.value.from = selectedDate
  }

  refreshAssignments()
}

const refreshAssignments = async () => {
  await Promise.all([
    assignmentsStore.fetchAssignments(dateRange.value.from, dateRange.value.to),
    assignmentsStore.fetchRouteMessages(dateRange.value.from, dateRange.value.to)
  ])

  if (assignmentsStore.error) {
    toastMessage.value = assignmentsStore.error
    showToast.value = true
  }
}

const handleRefresh = async (event: any) => {
  await refreshAssignments()
  event.target.complete()
}

const downloadRoutePlan = async () => {
  isDownloading.value = true
  const result = await assignmentsStore.downloadRoutePlan(dateRange.value.from, dateRange.value.to)
  
  if (result.success) {
    toastMessage.value = 'Route plan downloaded for offline use'
    showToast.value = true
  } else {
    toastMessage.value = result.message || 'Failed to download route plan'
    showToast.value = true
  }
  
  isDownloading.value = false
}

onMounted(() => {
  refreshAssignments()
})
</script>

<style scoped>
.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 200px;
  gap: 1rem;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 300px;
  text-align: center;
  padding: 2rem;
}

.empty-state h2 {
  margin: 1rem 0 0.5rem 0;
  color: var(--ion-color-medium);
}

.empty-state p {
  color: var(--ion-color-medium);
  margin: 0;
}

.date-filter-container {
  padding: 1rem;
  background: var(--ion-color-light);
  border-bottom: 1px solid var(--ion-color-light-shade);
}

.custom-date-range {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1rem;
}

.date-picker-group {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.date-picker-group ion-label {
  min-width: 50px;
  font-weight: 500;
}

.date-button {
  flex: 1;
}

.week-display {
  display: flex;
  justify-content: center;
  margin-top: 1rem;
}

.week-display ion-chip {
  font-weight: 500;
}

/* Day Group Styling */
.day-group {
  margin-bottom: 2rem;
}

.day-header {
  background: var(--ion-color-primary);
  color: var(--ion-color-primary-contrast);
  padding: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  top: 0;
  z-index: 10;
}

.day-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.day-info h2 {
  margin: 0;
  font-size: 1.2rem;
  font-weight: 600;
}

.day-date {
  font-size: 0.9rem;
  opacity: 0.9;
}

/* Day Messages Styling */
.day-messages {
  background: var(--ion-color-light);
  border-bottom: 1px solid var(--ion-color-light-shade);
}

.messages-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1rem;
  font-weight: 600;
  color: var(--ion-color-primary);
  border-bottom: 1px solid var(--ion-color-light-shade);
}

.messages-list {
  padding: 0.5rem 1rem 1rem;
}

.message-item {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 0.5rem 0;
  border-bottom: 1px solid var(--ion-color-light-shade);
}

.message-item:last-child {
  border-bottom: none;
}

.message-content {
  flex: 1;
}

.message-content p {
  margin: 0 0 0.25rem 0;
  font-size: 0.9rem;
}

.message-time {
  color: var(--ion-color-medium);
  font-size: 0.8rem;
}

/* Assignment Styling */
.day-assignments {
  margin: 0;
}

.assignment-content {
  flex: 1;
  padding: 0.5rem 0;
}

.assignment-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.5rem;
}

.assignment-header h3 {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  flex: 1;
}

.header-badges {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 0.25rem;
}

.assignment-details p {
  margin: 0.25rem 0;
  font-size: 0.9rem;
  color: var(--ion-color-medium);
}

.address {
  font-weight: 500;
  color: var(--ion-color-dark) !important;
}

.order-number {
  font-family: monospace;
  font-size: 0.8rem !important;
}

.assignment-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 0.5rem;
}

.items-count {
  font-weight: 500;
  color: var(--ion-color-primary) !important;
}

.assignment-time {
  font-weight: 500;
  color: var(--ion-color-secondary) !important;
}
</style>

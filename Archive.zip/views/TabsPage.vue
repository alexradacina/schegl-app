<template>
  <ion-page>
    <ion-tabs>
      <ion-router-outlet />

      <ion-tab-bar slot="bottom" class="custom-tab-bar">
        <div class="network-status" :class="{ offline: !isOnline }">
          <ion-icon :icon="isOnline ? wifiOutline : wifiOutline" />
          <span>{{ isOnline ? 'Online' : 'Offline' }}</span>
          <ion-badge v-if="pendingSync > 0" color="warning">{{ pendingSync }}</ion-badge>
        </div>

        <ion-tab-button tab="assignments" href="/tabs/assignments">
          <ion-icon :icon="listOutline" />
          <ion-label>Assignments</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="profile" href="/tabs/profile">
          <ion-icon :icon="personOutline" />
          <ion-label>Profile</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="draw" href="/tabs/draw">
          <ion-icon :icon="personOutline" />
          <ion-label>Draw</ion-label>
        </ion-tab-button>
      </ion-tab-bar>
    </ion-tabs>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonTabs,
  IonTabBar,
  IonTabButton,
  IonRouterOutlet,
  IonLabel,
  IonIcon,
  IonBadge,
} from '@ionic/vue'
import { listOutline, personOutline, wifiOutline } from 'ionicons/icons'
import { useNetworkStatus } from '@/composables/useNetworkStatus'
import { useOfflineStorage } from '@/composables/useOfflineStorage'
import { useOfflineSync } from '@/composables/useOfflineSync'
import { ref, watch, onMounted } from 'vue'

const { isOnline } = useNetworkStatus()
const { getOfflineQueue } = useOfflineStorage()
const { syncOfflineData } = useOfflineSync()
const pendingSync = ref(0)

const updatePendingCount = async () => {
  const queue = await getOfflineQueue()
  pendingSync.value = queue.filter(item => !item.synced).length
}

watch(isOnline, async (online) => {
  if (online && pendingSync.value > 0) {
    console.log('[v0] Coming online, starting auto-sync')
    await syncOfflineData()
    await updatePendingCount()
  }
})

onMounted(() => {
  updatePendingCount()
  setInterval(updatePendingCount, 30000)
})
</script>

<style scoped>
.custom-tab-bar {
  padding-bottom: 25px;
  position: relative;
}

.network-status {
  position: absolute;
  top: 4px;
  right: 8px;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 12px;
  background: var(--ion-color-success);
  color: white;
  font-size: 11px;
  font-weight: 600;
  z-index: 10;
}

.network-status.offline {
  background: var(--ion-color-danger);
}

.network-status ion-icon {
  font-size: 14px;
}

.network-status ion-badge {
  margin-left: 4px;
}
</style>

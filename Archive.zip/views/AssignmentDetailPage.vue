<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button default-href="/tabs/assignments"></ion-back-button>
        </ion-buttons>
        <ion-title>Assignment Details</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div v-if="assignmentsStore.isLoading" class="loading-container">
        <ion-spinner name="crescent"></ion-spinner>
        <p>Loading assignment...</p>
      </div>

      <div v-else-if="!assignment" class="error-container">
        <ion-icon :icon="alertCircleOutline" size="large"></ion-icon>
        <h2>Assignment Not Found</h2>
        <p>The assignment doesn't exist or you don't have access.</p>
        <ion-button @click="goBack" fill="outline">Back to Assignments</ion-button>
      </div>

      <div v-else class="assignment-details">
        <!-- Assignment Info -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>{{ assignment.order?.customer?.name || 'Unknown Customer' }}</ion-card-title>
            <ion-card-subtitle>{{ assignment.address?.street || 'No address' }}</ion-card-subtitle>
          </ion-card-header>
          <ion-card-content>
            <div class="detail-row">
              <ion-label>Status:</ion-label>
              <ion-chip :color="getStatusColor(assignment.status)">
                {{ assignment.status || 'unclear' }}
              </ion-chip>
            </div>
            <div class="detail-row">
              <ion-label>Date:</ion-label>
              <span>{{ assignment.date || 'No date set' }}</span>
            </div>
            <div class="detail-row">
              <ion-label>Number of Items:</ion-label>
              <span>{{ assignment.number_of_items || 0 }}</span>
            </div>
            <div class="detail-row" v-if="assignment.notes">
              <ion-label>Notes:</ion-label>
              <span>{{ assignment.notes }}</span>
            </div>
          </ion-card-content>
        </ion-card>

        <ion-card>
          <ion-card-header>
            <ion-card-title>Update Status</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-item>
              <ion-label>Status</ion-label>
              <ion-select v-model="selectedStatus" placeholder="Select status">
                <ion-select-option value="unclear">Unclear</ion-select-option>
                <ion-select-option value="pending">Pending</ion-select-option>
                <ion-select-option value="in_progress">In Progress</ion-select-option>
                <ion-select-option value="completed">Completed</ion-select-option>
                <ion-select-option value="cancelled">Cancelled</ion-select-option>
              </ion-select>
            </ion-item>
            <ion-button @click="updateStatus" expand="block" :disabled="assignmentsStore.isLoading || selectedStatus === assignment.status">
              <ion-spinner v-if="assignmentsStore.isLoading" name="crescent"></ion-spinner>
              <span v-else>Update Status</span>
            </ion-button>
          </ion-card-content>
        </ion-card>

        <ion-card>
          <ion-card-header>
            <div class="machines-header">
              <ion-card-title>Machines at this Address</ion-card-title>
              <ion-button @click="openCreateMachineModal" fill="outline" size="small">
                <ion-icon :icon="addOutline" slot="start"></ion-icon>
                Add Machine
              </ion-button>
            </div>
          </ion-card-header>
          <ion-card-content>
            <div v-if="machinesStore.isLoading" class="loading-container">
              <ion-spinner name="crescent"></ion-spinner>
              <p>Loading machines...</p>
            </div>
            <div v-else-if="addressMachines.length === 0" class="empty-state">
              <ion-icon :icon="constructOutline" size="large"></ion-icon>
              <p>No machines found at this address</p>
            </div>
            <div v-else>
              <ion-item v-for="machine in addressMachines" :key="machine.id" button @click="openMachineOrderModal(machine)">
                <ion-icon :icon="constructOutline" slot="start"></ion-icon>
                <ion-label>
                  <h3>{{ machine.internal_number }}</h3>
                  <p>{{ machine.object }}</p>
                  <p v-if="machine.producer">{{ machine.producer }} - {{ machine.type }}</p>
                </ion-label>
                <div slot="end" class="machine-status">
                  <ion-chip v-if="getMachineOrderStatus(machine.id) !== null" :color="getStatusColor(getMachineOrderStatus(machine.id))" size="small">
                    {{ getMachineOrderStatusLabel(machine.id) }}
                  </ion-chip>
                  <ion-chip v-else color="light" size="small">No Order</ion-chip>
                </div>
              </ion-item>
            </div>
          </ion-card-content>
        </ion-card>
      </div>

      <!-- Modals (v-show instead of v-if) -->
      <CreateMachineModal v-show="showCreateMachine" :is-open="showCreateMachine" :address-id="assignment?.address?.id" :customer-id="assignment?.order?.customer?.id" @close="showCreateMachine = false" @created="onMachineCreated"/>
      <MachineOrderModal v-show="showMachineOrderModal" :is-open="showMachineOrderModal" :machine="selectedMachine" :order-address-id="getOrderAddressId()" @close="showMachineOrderModal = false" @created="onMachineOrderCreated" @updated="onMachineOrderUpdated"/>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonItem, IonLabel, IonSelect, IonSelectOption, IonButton, IonChip, IonSpinner, IonIcon, toastController } from '@ionic/vue'
import { alertCircleOutline, addOutline, constructOutline, chevronForwardOutline } from 'ionicons/icons'
import { useAssignmentsStore } from '@/stores/assignments'
import { useMachinesStore } from '@/stores/machines'
import { useMachineOrdersStore } from '@/stores/machineOrders'
import CreateMachineModal from '@/components/CreateMachineModal.vue'
import MachineOrderModal from '@/components/MachineOrderModal.vue'

const route = useRoute()
const router = useRouter()
const assignmentsStore = useAssignmentsStore()
const machinesStore = useMachinesStore()
const machineOrdersStore = useMachineOrdersStore()

const assignment = computed(() => assignmentsStore.currentAssignment)
const selectedStatus = ref('')
const showCreateMachine = ref(false)
const showMachineOrderModal = ref(false)
const selectedMachine = ref<any>(null)

const addressMachines = computed(() => {
  if (!Array.isArray(machinesStore.machines) || !assignment.value?.address?.id) return []
  return machinesStore.machines.filter(machine => machine.address_id === assignment.value?.address?.id)
})

const goBack = () => router.push('/tabs/assignments')

const getOrderAddressId = () => assignment.value?.order_address_id || assignment.value?.id

const openMachineOrderModal = async (machine: any) => {
  selectedMachine.value = machine
  await machineOrdersStore.fetchMachineOrders() // preload
  showMachineOrderModal.value = true
}

const openCreateMachineModal = () => showCreateMachine.value = true

const getStatusColor = (status: string | number | null | undefined) => {
  if (!status) return 'medium'
  if (typeof status === 'number') {
    return {1:'success',2:'warning',3:'danger',4:'dark'}[status]||'medium'
  }
  return {completed:'success',in_progress:'warning',pending:'primary',cancelled:'danger',unclear:'medium'}[status.toLowerCase()]||'medium'
}

const getMachineOrderStatus = (machineId:number) => {
  const orderAddressId = getOrderAddressId()
  const order = machineOrdersStore.machineOrders.find(o => o.machine?.id === machineId && o.order_address_id === orderAddressId)
  return order?.status ?? null
}

const getMachineOrderStatusLabel = (machineId:number) => {
  const status = getMachineOrderStatus(machineId)
  if (status === null) return null
  return {0:'To Do',1:'No Issues',2:'Remark',3:'Severe Issue',4:'Retired'}[status] || 'Unknown'
}

const updateStatus = async () => {
  if (!assignment.value) return
  const result = await assignmentsStore.updateAssignmentStatus(assignment.value.id, selectedStatus.value)
  const toast = await toastController.create({
    message: result.success ? 'Status updated successfully' : (result.message || 'Failed to update status'),
    duration: 2000,
    color: result.success ? 'success':'danger'
  })
  await toast.present()
  if(result.success) await assignmentsStore.fetchAssignmentById(assignment.value.id)
}

const onMachineCreated = async () => {
  showCreateMachine.value = false
  await machinesStore.fetchMachines()
}

const onMachineOrderCreated = async () => {
  showMachineOrderModal.value = false
  selectedMachine.value = null
  await machineOrdersStore.fetchMachineOrders()
}

const onMachineOrderUpdated = async () => {
  await machineOrdersStore.fetchMachineOrders()
}

onMounted(async () => {
  const assignmentId = parseInt(route.params.id as string)
  await assignmentsStore.fetchAssignmentById(assignmentId)
  await machinesStore.fetchMachines()
  await machineOrdersStore.fetchMachineOrders()
  if (assignment.value) selectedStatus.value = assignment.value.status || 'unclear'
})
</script>

<style scoped>
.loading-container, .error-container, .empty-state {
  display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:2rem;
}
.assignment-details {padding:1rem;}
.detail-row {display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;}
.machines-header {display:flex; justify-content:space-between; align-items:center;}
.machine-status {display:flex; align-items:center; gap:0.5rem;}
</style>

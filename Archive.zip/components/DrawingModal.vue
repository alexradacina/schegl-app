<template>
  <ion-modal :is-open="isOpen" @didDismiss="handleClose" class="fullscreen-modal">
    <ion-page>
      <ion-header>
        <ion-toolbar class="compact-toolbar">
          <ion-title size="small">Drawing: {{ drawingId }}</ion-title>
          <ion-buttons slot="start">
            <ion-button @click="handleClose">
              <ion-icon :icon="closeOutline"></ion-icon>
            </ion-button>
          </ion-buttons>
          <ion-buttons slot="end">
            <ion-chip :color="saveStatus === 'saved' ? 'success' : 'warning'" size="small">
              <ion-icon :icon="saveStatus === 'saved' ? checkmarkCircleOutline : cloudUploadOutline" />
              <ion-label>{{ saveStatus === 'saved' ? 'Saved' : 'Saving...' }}</ion-label>
            </ion-chip>
            <ion-button @click="undo" :disabled="!canUndo" size="small">
              <ion-icon :icon="arrowUndoOutline"></ion-icon>
            </ion-button>
            <ion-button @click="redo" :disabled="!canRedo" size="small">
              <ion-icon :icon="arrowRedoOutline"></ion-icon>
            </ion-button>
            <ion-button @click="confirmClearCanvas" size="small">
              <ion-icon :icon="trashOutline"></ion-icon>
            </ion-button>
            <ion-button @click="downloadCanvas" size="small">
              <ion-icon :icon="downloadOutline"></ion-icon>
            </ion-button>
          </ion-buttons>
        </ion-toolbar>

        <ion-toolbar class="compact-toolbar">
          <div class="toolbar-compact">
            <!-- Tool selection -->
            <div class="tool-section-compact">
              <ion-button
                  v-for="tool in tools"
                  :key="tool.name"
                  :color="currentTool === tool.name ? 'primary' : 'medium'"
                  fill="clear"
                  size="small"
                  @click="selectTool(tool.name)"
              >
                <ion-icon :icon="tool.icon" size="small"></ion-icon>
              </ion-button>
            </div>

            <!-- Canvas size controls -->
            <div class="canvas-size-compact">
              <input
                  type="number"
                  v-model.number="canvasSize.width"
                  @change="resizeCanvas"
                  min="100"
                  step="100"
                  placeholder="W"
              />
              <span>×</span>
              <input
                  type="number"
                  v-model.number="canvasSize.height"
                  @change="resizeCanvas"
                  min="100"
                  step="100"
                  placeholder="H"
              />
              <ion-button size="small" fill="outline" @click="fitToScreen">
                Fit
              </ion-button>
            </div>

            <!-- Tool options -->
            <div class="tool-options-compact" v-if="currentTool === 'pencil'">
              <div class="line-sizes-compact">
                <button
                    v-for="size in lineSizes"
                    :key="size.value"
                    class="line-size-btn-compact"
                    :class="{ active: pencilOptions.strokeWidth === size.value }"
                    @click="pencilOptions.strokeWidth = size.value"
                >
                  <div class="line-preview" :style="{ height: size.value + 'px' }"></div>
                </button>
              </div>

              <div class="color-picker-compact">
                <div
                    v-for="color in predefinedColors"
                    :key="color"
                    class="color-swatch-compact"
                    :style="{ backgroundColor: color }"
                    :class="{ active: pencilOptions.color === color }"
                    @click="pencilOptions.color = color"
                ></div>
                <input
                    type="color"
                    v-model="pencilOptions.color"
                    class="custom-color-picker-compact"
                />
              </div>
            </div>

            <div class="tool-options-compact" v-if="currentTool === 'eraser'">
              <span class="hint-text">Tap to delete</span>
            </div>

            <div class="tool-options-compact" v-if="currentTool === 'image'">
              <ion-button size="small" @click="addImage">
                <ion-icon slot="start" :icon="imageOutline" size="small"></ion-icon>
                Image
              </ion-button>
            </div>
          </div>
        </ion-toolbar>
      </ion-header>

      <ion-content :scroll-y="true" :scroll-x="true" ref="contentRef">
        <div class="canvas-container">
          <canvas id="drawing-canvas" ref="canvasEl"></canvas>
        </div>
      </ion-content>
    </ion-page>
  </ion-modal>
</template>

<script setup>
import { ref, onMounted, reactive, computed, watch, onUnmounted } from 'vue';
import {
  IonModal, IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonButton, IonIcon, IonButtons, IonChip, IonLabel, alertController
} from '@ionic/vue';
import {
  pencilOutline, trashOutline, downloadOutline,
  imageOutline, handRightOutline, arrowUndoOutline,
  arrowRedoOutline, closeOutline, checkmarkCircleOutline, cloudUploadOutline
} from 'ionicons/icons';
import { fabric } from 'fabric';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Capacitor } from '@capacitor/core';

const props = defineProps({
  isOpen: {
    type: Boolean,
    default: false
  },
  drawingId: {
    type: String,
    required: true
  }
});

const emit = defineEmits(['close']);

const isNative = Capacitor.isNativePlatform();

const currentTool = ref('pencil');
const canvasEl = ref(null);
const contentRef = ref(null);
let canvas = null;
let drawingModeInitialized = false;

const canvasSize = reactive({
  width: 0,
  height: 0
});

const history = ref([]);
const historyIndex = ref(-1);
const maxHistorySteps = 50;

const canUndo = computed(() => historyIndex.value > 0);
const canRedo = computed(() => historyIndex.value < history.value.length - 1);

const pencilOptions = reactive({
  strokeWidth: 3,
  color: '#000000'
});

const lineSizes = [
  { name: 'XS', value: 1 },
  { name: 'S', value: 3 },
  { name: 'M', value: 5 },
  { name: 'L', value: 8 }
];

const predefinedColors = [
  '#000000', '#ffffff', '#ff0000', '#00ff00', '#0000ff',
  '#ffff00', '#ff00ff', '#00ffff', '#ff9900', '#9900ff'
];

const tools = [
  { name: 'pencil', icon: pencilOutline },
  { name: 'eraser', icon: trashOutline },
  { name: 'image', icon: imageOutline },
  { name: 'select', icon: handRightOutline }
];

const saveStatus = ref('saved');
let saveTimeout = null;

const handleClose = async () => {
  await saveDrawing();
  cleanupCanvas();
  emit('close');
};

const cleanupCanvas = () => {
  if (canvas) {
    canvas.off(); // Remove all event listeners
    canvas.dispose(); // Properly dispose of the canvas
    canvas = null;
  }

  if (canvasEl.value) {
    canvasEl.value.removeEventListener('pointerdown', handlePointerDown);
    canvasEl.value.removeEventListener('pointerup', handlePointerUp);
  }

  drawingModeInitialized = false;
  history.value = [];
  historyIndex.value = -1;
};

const saveDrawing = async () => {
  if (!canvas) return;

  saveStatus.value = 'saving';

  const json = canvas.toJSON(['data']);
  const data = {
    canvas: json,
    width: canvasSize.width,
    height: canvasSize.height,
    timestamp: Date.now()
  };

  try {
    const jsonData = JSON.stringify(data);
    
    if (isNative) {
      // Native: Use Capacitor Filesystem
      await Filesystem.writeFile({
        path: `drawings/drawing_${props.drawingId}.json`,
        data: jsonData,
        directory: Directory.Data,
        recursive: true,
      });
      console.log('[v0] Drawing saved to filesystem (native)');
    } else {
      // Web: Use localStorage as fallback
      localStorage.setItem(`drawing_${props.drawingId}`, jsonData);
      console.log('[v0] Drawing saved to localStorage (web)');
    }

    saveStatus.value = 'saved';
  } catch (error) {
    console.error('[v0] Error saving drawing:', error);
    saveStatus.value = 'error';
  }
};

const loadDrawing = async () => {
  try {
    let dataString;
    
    if (isNative) {
      // Native: Use Capacitor Filesystem
      const result = await Filesystem.readFile({
        path: `drawings/drawing_${props.drawingId}.json`,
        directory: Directory.Data,
      });
      dataString = result.data;
      console.log('[v0] Drawing loaded from filesystem (native)');
    } else {
      // Web: Use localStorage as fallback
      dataString = localStorage.getItem(`drawing_${props.drawingId}`);
      console.log('[v0] Drawing loaded from localStorage (web)');
    }

    if (!dataString) {
      console.log('[v0] No existing drawing found');
      return;
    }

    const data = JSON.parse(dataString);

    // Restore canvas size
    canvasSize.width = data.width;
    canvasSize.height = data.height;
    canvas.setWidth(canvasSize.width);
    canvas.setHeight(canvasSize.height);

    // Restore canvas content
    canvas.loadFromJSON(data.canvas, () => {
      canvas.renderAll();
      saveToHistory();
    });
  } catch (error) {
    console.log('[v0] No existing drawing found or error loading:', error);
  }
};

const fitToScreen = async () => {
  await new Promise(resolve => setTimeout(resolve, 100));

  if (contentRef.value && contentRef.value.$el) {
    const contentElement = contentRef.value.$el;
    const rect = contentElement.getBoundingClientRect();

    const padding = 40;

    canvasSize.width = rect.width - padding;
    canvasSize.height = rect.height - padding;

    resizeCanvas();
  }
};

const resizeCanvas = async () => {
  if (!canvas) return;

  canvas.setWidth(canvasSize.width);
  canvas.setHeight(canvasSize.height);
  canvas.renderAll();

  debouncedSave(); // Use debounced save
};

const handlePointerDown = (e) => {
  console.log('[v0] Pointer down:', e.pointerType, 'Tool:', currentTool.value);

  if (e.pointerType === 'touch') {
    if (currentTool.value === 'pencil') {
      e.preventDefault();
      e.stopPropagation();
      canvas.isDrawingMode = false;
      return false;
    }
  }

  if (e.pointerType === 'pen' && currentTool.value === 'pencil') {
    canvas.isDrawingMode = true;
  }
};

const handlePointerUp = (e) => {
  if (currentTool.value === 'pencil' && e.pointerType === 'pen') {
    canvas.isDrawingMode = true;
  }
};

const initializeDrawingMode = () => {
  if (!canvas || drawingModeInitialized) return;

  canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
  canvas.freeDrawingBrush.color = pencilOptions.color;
  canvas.freeDrawingBrush.width = pencilOptions.strokeWidth;

  canvas.on('path:created', async () => {
    const objects = canvas.getObjects();
    const lastObject = objects[objects.length - 1];
    if (lastObject) {
      lastObject.selectable = currentTool.value === 'select';
      lastObject.evented = currentTool.value === 'select';
    }

    saveToHistory();
    debouncedSave(); // Use debounced save
  });

  drawingModeInitialized = true;
};

const selectTool = (toolName) => {
  currentTool.value = toolName;

  initializeDrawingMode();

  if (canvas) {
    canvas.off('mouse:down', handleEraserClick);

    if (toolName === 'pencil') {
      canvas.isDrawingMode = true;
      canvas.selection = false;
      canvas.freeDrawingBrush.color = pencilOptions.color;
      canvas.freeDrawingBrush.width = pencilOptions.strokeWidth;

      canvas.getObjects().forEach(obj => {
        obj.selectable = false;
        obj.evented = false;
      });

      canvas.skipTargetFind = true;

    } else if (toolName === 'eraser') {
      canvas.isDrawingMode = false;
      canvas.selection = false;

      canvas.getObjects().forEach(obj => {
        obj.selectable = true;
        obj.evented = true;
        obj.hoverCursor = 'pointer';
      });

      canvas.skipTargetFind = false;
      canvas.on('mouse:down', handleEraserClick);

    } else if (toolName === 'select') {
      canvas.isDrawingMode = false;
      canvas.selection = true;

      canvas.getObjects().forEach(obj => {
        obj.selectable = true;
        obj.evented = true;
        obj.hoverCursor = 'move';
      });

      canvas.skipTargetFind = false;

    } else if (toolName === 'image') {
      canvas.isDrawingMode = false;
      canvas.selection = false;

      canvas.getObjects().forEach(obj => {
        obj.selectable = false;
        obj.evented = false;
      });

      canvas.skipTargetFind = true;
    }

    canvas.renderAll();
  }
};

const handleEraserClick = async (e) => {
  if (currentTool.value === 'eraser' && e.target) {
    canvas.remove(e.target);
    canvas.renderAll();
    saveToHistory();
    debouncedSave(); // Use debounced save
  }
};

const updatePencilOptions = () => {
  if (canvas && canvas.freeDrawingBrush && currentTool.value === 'pencil') {
    canvas.freeDrawingBrush.color = pencilOptions.color;
    canvas.freeDrawingBrush.width = pencilOptions.strokeWidth;
  }
};

const debouncedSave = () => {
  saveStatus.value = 'saving';

  if (saveTimeout) {
    clearTimeout(saveTimeout);
  }

  saveTimeout = setTimeout(async () => {
    await saveDrawing();
  }, 1000);
};

watch(() => props.isOpen, async (isOpen) => {
  if (isOpen) {
    await new Promise(resolve => setTimeout(resolve, 300));

    if (!canvas) {
      await initCanvas();
    } else {
      await loadDrawing();
    }
  } else {
    if (canvas) {
      await saveDrawing();
      cleanupCanvas();
    }
  }
});

const initCanvas = async () => {
  console.log('[v0] Initializing canvas');

  await fitToScreen();

  canvas = new fabric.Canvas('drawing-canvas', {
    isDrawingMode: false,
    selection: false,
    width: canvasSize.width,
    height: canvasSize.height,
    renderOnAddRemove: false,
    stateful: false,
    skipTargetFind: true,
    enableRetinaScaling: true,
    allowTouchScrolling: false
  });

  if (canvasEl.value) {
    canvasEl.value.style.touchAction = 'none';
    canvasEl.value.addEventListener('pointerdown', handlePointerDown, { capture: true });
    canvasEl.value.addEventListener('pointerup', handlePointerUp, { capture: true });
    canvasEl.value.addEventListener('touchstart', (e) => {
      if (currentTool.value === 'pencil') {
        e.preventDefault();
        e.stopPropagation();
      }
    }, { passive: false, capture: true });
  }

  canvas.on('object:modified', async (e) => {
    if (e.target && e.target.type === 'image') {
      e.target.sendToBack();
    }
    canvas.renderAll();
    saveToHistory();
    debouncedSave(); // Use debounced save
  });

  initializeDrawingMode();
  selectTool('pencil');

  await loadDrawing();

  if (history.value.length === 0) {
    saveToHistory();
  }

  console.log('[v0] Canvas initialized:', canvasSize.width, 'x', canvasSize.height);
};

const addImage = () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';

  input.style.position = 'fixed';
  input.style.left = '0';
  input.style.top = '0';
  input.style.opacity = '0.001';
  document.body.appendChild(input);

  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (f) => {
        const data = f.target.result;
        fabric.Image.fromURL(data, async (img) => {
          const maxWidth = canvas.width * 0.8;
          const maxHeight = canvas.height * 0.8;

          if (img.width > maxWidth || img.height > maxHeight) {
            const scale = Math.min(maxWidth / img.width, maxHeight / img.height);
            img.scale(scale);
          }

          img.set({
            left: canvas.width / 2 - (img.width * img.scaleX) / 2,
            top: canvas.height / 2 - (img.height * img.scaleY) / 2,
            selectable: currentTool.value === 'select',
            evented: currentTool.value === 'select'
          });

          canvas.add(img);
          img.sendToBack();
          canvas.renderAll();
          saveToHistory();
          debouncedSave(); // Use debounced save
        });
      };
      reader.readAsDataURL(file);
    }

    document.body.removeChild(input);
  };

  input.click();
};

const saveToHistory = () => {
  const json = canvas.toJSON(['data']);

  if (historyIndex.value < history.value.length - 1) {
    history.value = history.value.slice(0, historyIndex.value + 1);
  }

  history.value.push({
    canvas: json
  });

  if (history.value.length > maxHistorySteps) {
    history.value = history.value.slice(history.value.length - maxHistorySteps);
  }

  historyIndex.value = history.value.length - 1;
};

const undo = async () => {
  if (!canUndo.value) return;

  historyIndex.value--;
  restoreFromHistory();
  debouncedSave(); // Use debounced save
};

const redo = async () => {
  if (!canRedo.value) return;

  historyIndex.value++;
  restoreFromHistory();
  debouncedSave(); // Use debounced save
};

const restoreFromHistory = () => {
  const state = history.value[historyIndex.value];

  canvas.loadFromJSON(state.canvas, () => {
    const tool = currentTool.value;

    canvas.getObjects().forEach(obj => {
      if (tool === 'select' || tool === 'eraser') {
        obj.selectable = true;
        obj.evented = true;
        obj.hoverCursor = tool === 'select' ? 'move' : 'pointer';
      } else {
        obj.selectable = false;
        obj.evented = false;
      }

      if (obj.type === 'image') {
        obj.sendToBack();
      }
    });

    canvas.renderAll();
  });
};

const confirmClearCanvas = async () => {
  const alert = await alertController.create({
    header: 'Clear Canvas',
    message: 'Are you sure you want to clear the entire canvas?',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel'
      },
      {
        text: 'Clear',
        handler: () => {
          clearCanvas();
        }
      }
    ]
  });

  await alert.present();
};

const clearCanvas = async () => {
  canvas.clear();
  canvas.renderAll();
  saveToHistory();
  debouncedSave(); // Use debounced save
};

const downloadCanvas = () => {
  const dataURL = canvas.toDataURL({
    format: 'png',
    quality: 1
  });

  const link = document.createElement('a');
  link.download = `drawing_${props.drawingId}.png`;
  link.href = dataURL;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

onUnmounted(() => {
  if (saveTimeout) {
    clearTimeout(saveTimeout);
  }
  cleanupCanvas();
});

watch(() => pencilOptions.strokeWidth, updatePencilOptions);
watch(() => pencilOptions.color, updatePencilOptions);
</script>

<style scoped>
.fullscreen-modal {
  --width: 100%;
  --height: 100%;
  --border-radius: 0;
}

.canvas-container {
  display: inline-block;
  background-color: #ffffff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  margin: 8px;
  touch-action: none;
}

#drawing-canvas {
  display: block;
  border: 1px solid #ddd;
  touch-action: none;
}

.compact-toolbar {
  --min-height: 44px;
}

.toolbar-compact {
  padding: 4px 8px;
  background-color: #f5f5f5;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  justify-content: space-between;
}

.tool-section-compact {
  display: flex;
  gap: 2px;
}

.canvas-size-compact {
  display: flex;
  align-items: center;
  gap: 4px;
}

.canvas-size-compact input {
  width: 60px;
  padding: 2px 4px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 12px;
  text-align: center;
}

.canvas-size-compact span {
  color: #666;
  font-size: 12px;
}

.tool-options-compact {
  display: flex;
  align-items: center;
  gap: 6px;
}

.hint-text {
  font-size: 11px;
  color: #666;
  padding: 2px 6px;
  background-color: #fff3cd;
  border-radius: 3px;
}

.color-picker-compact {
  display: flex;
  gap: 3px;
  align-items: center;
}

.color-swatch-compact {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 1px solid #ccc;
  cursor: pointer;
  transition: transform 0.2s ease;
}

.color-swatch-compact:hover {
  transform: scale(1.1);
}

.color-swatch-compact.active {
  border: 2px solid #000;
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
}

.custom-color-picker-compact {
  width: 20px;
  height: 20px;
  border: none;
  padding: 0;
  background: none;
  cursor: pointer;
}

.line-sizes-compact {
  display: flex;
  gap: 4px;
  align-items: center;
}

.line-size-btn-compact {
  width: 28px;
  height: 28px;
  border-radius: 3px;
  border: 1px solid #ccc;
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
}

.line-size-btn-compact:hover {
  background-color: #f0f0f0;
}

.line-size-btn-compact.active {
  background-color: #e0e0e0;
  border-color: #999;
  box-shadow: inset 0 0 2px rgba(0, 0, 0, 0.2);
}

.line-preview {
  width: 16px;
  background-color: #000;
  border-radius: 2px;
}
</style>

<template>
  <ion-modal
      :is-open="isOpen"
      @did-dismiss="$emit('close')"
      :initial-breakpoint="existingOrder ? 1 : 0.6"
      :breakpoints="[0, 0.6, 0.9, 1]"
  >
    <ion-header>
      <ion-toolbar>
        <ion-title>{{ existingOrder ? 'Machine Order Details' : 'Create Machine Order' }}</ion-title>
        <ion-buttons slot="end">
          <ion-button @click="$emit('close')">
            <ion-icon :icon="closeOutline"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <!-- Loading -->
      <div v-if="isLoading" class="loading-container">
        <ion-spinner name="crescent"></ion-spinner>
        <p>{{ existingOrder ? 'Loading machine order...' : 'Checking existing orders...' }}</p>
      </div>

      <!-- Existing Order -->
      <div v-else-if="existingOrder">
        <!-- Machine Order Details -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>{{ machine?.internal_number }}</ion-card-title>
            <ion-card-subtitle>{{ machine?.object }}</ion-card-subtitle>
          </ion-card-header>
          <ion-card-content>
            <div class="detail-row">
              <ion-label>Status:</ion-label>
              <ion-chip :color="getStatusColor(existingOrder.status)">
                {{ getStatusLabel(existingOrder.status) }}
              </ion-chip>
            </div>
            <div class="detail-row" v-if="existingOrder.template">
              <ion-label>Template:</ion-label>
              <span>{{ existingOrder.template.name }}</span>
            </div>
            <div class="detail-row" v-if="existingOrder.date">
              <ion-label>Date:</ion-label>
              <span>{{ formatDate(existingOrder.date) }}</span>
            </div>
          </ion-card-content>
        </ion-card>

        <!-- Template Selection -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Template</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-item>
              <ion-select
                  v-model="selectedTemplateId"
                  placeholder="Choose template"
                  interface="popover"
                  label="Select Template"
              >
                <ion-select-option value="">No Template</ion-select-option>
                <ion-select-option
                    v-for="template in availableTemplates"
                    :key="template.id"
                    :value="template.id"
                >
                  {{ template.name }}
                </ion-select-option>
              </ion-select>
            </ion-item>
            <ion-button
                @click="assignTemplate"
                expand="block"
                :disabled="selectedTemplateId === (existingOrder.template?.id || '')"
            >
              {{ selectedTemplateId ? 'Assign Template' : 'Remove Template' }}
            </ion-button>
          </ion-card-content>
        </ion-card>

        <!-- Status Update -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Update Status & Details</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-item>
              <ion-select
                  v-model="selectedStatus"
                  placeholder="Select status"
                  interface="popover"
                  label="Status"
              >
                <ion-select-option value="0">To Do</ion-select-option>
                <ion-select-option value="1">No Issues</ion-select-option>
                <ion-select-option value="2">Remark</ion-select-option>
                <ion-select-option value="3">Severe Issue</ion-select-option>
                <ion-select-option value="4">Retired</ion-select-option>
              </ion-select>
            </ion-item>

            <ion-item>
              <ion-label position="stacked">Issues</ion-label>
              <ion-textarea
                  v-model="issues"
                  placeholder="Describe any issues..."
                  :rows="3"
              ></ion-textarea>
            </ion-item>

            <ion-item>
              <ion-label position="stacked">Remarks</ion-label>
              <ion-textarea
                  v-model="remarks"
                  placeholder="Additional remarks..."
                  :rows="3"
              ></ion-textarea>
            </ion-item>

            <ion-button @click="updateStatus" expand="block">
              Update Machine Order
            </ion-button>
          </ion-card-content>
        </ion-card>

        <!-- Template Form -->
        <ion-card v-if="existingOrder.template?.form_sections?.length">
          <ion-card-header>
            <ion-card-title>{{ existingOrder.template.form_title || 'Template Form' }}</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <div v-for="section in existingOrder.template.form_sections" :key="section.id" class="form-section">
              <h3>{{ section.title }}</h3>
              <p v-if="section.description">{{ section.description }}</p>

              <div v-for="field in section.fields" :key="field.id" class="form-field">
                <ion-item>
                  <ion-label position="stacked">
                    {{ field.label }}
                    <span v-if="field.required" class="required">*</span>
                  </ion-label>

                  <ion-input v-if="field.type === 'text'" v-model="formResponses[field.id]" :placeholder="field.label" />
                  <ion-textarea v-else-if="field.type === 'textarea'" v-model="formResponses[field.id]" :placeholder="field.label" :rows="3" />
                  <ion-select
                      v-else-if="field.type === 'select'"
                      v-model="formResponses[field.id]"
                      interface="popover"
                  >
                    <ion-select-option v-for="option in field.options" :key="option" :value="option">
                      {{ option }}
                    </ion-select-option>
                  </ion-select>
                  <ion-checkbox v-else-if="field.type === 'checkbox'" v-model="formResponses[field.id]" />
                  <ion-input v-else-if="field.type === 'number'" v-model="formResponses[field.id]" type="number" :placeholder="field.label" />
                </ion-item>
              </div>
            </div>

            <ion-button @click="saveFormResponses" expand="block" color="success">
              Save Form Responses
            </ion-button>
          </ion-card-content>
        </ion-card>
      </div>

      <!-- New Order -->
      <div v-else>
        <ion-card>
          <ion-card-header>
            <ion-card-title>Create Machine Order</ion-card-title>
            <ion-card-subtitle>{{ machine?.internal_number }}</ion-card-subtitle>
          </ion-card-header>
          <ion-card-content>
            <div v-if="suggestedTemplate" class="suggested-template">
              <ion-item>
                <ion-icon :icon="bulbOutline" slot="start" color="warning"></ion-icon>
                <ion-label>
                  <h3>Suggested Template</h3>
                  <p>{{ suggestedTemplate.name }}</p>
                  <p><small>Based on previous orders for this machine</small></p>
                </ion-label>
              </ion-item>
            </div>

            <ion-item>
              <ion-select
                  v-model="selectedTemplateId"
                  placeholder="Choose template"
                  interface="popover"
              >
                <ion-select-option value="">No Template</ion-select-option>
                <ion-select-option v-for="template in availableTemplates" :key="template.id" :value="template.id">
                  {{ template.name }}
                </ion-select-option>
              </ion-select>
            </ion-item>

            <ion-item>
              <ion-select v-model="selectedStatus" placeholder="Select status" interface="popover">
                <ion-select-option value="0">To Do</ion-select-option>
                <ion-select-option value="1">No Issues</ion-select-option>
                <ion-select-option value="2">Remark</ion-select-option>
                <ion-select-option value="3">Severe Issue</ion-select-option>
                <ion-select-option value="4">Retired</ion-select-option>
              </ion-select>
            </ion-item>

            <ion-button @click="createMachineOrder" expand="block">Create Machine Order</ion-button>
          </ion-card-content>
        </ion-card>
      </div>
    </ion-content>
  </ion-modal>
</template>

<script setup lang="ts">
import {
  IonModal,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButtons,
  IonButton,
  IonIcon,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonItem,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonTextarea,
  IonInput,
  IonCheckbox,
  IonSpinner,
  IonChip,
  toastController,
} from '@ionic/vue'
import { closeOutline, bulbOutline } from 'ionicons/icons'
import { ref, computed, watch, nextTick, onMounted } from 'vue'
import { useMachineOrdersStore } from '@/stores/machineOrders'
import { useTemplatesStore } from '@/stores/templates'

interface Props {
  isOpen: boolean
  machine: any
  orderAddressId: number
}

const props = defineProps<Props>()
const emit = defineEmits(['close', 'created', 'updated'])

const machineOrdersStore = useMachineOrdersStore()
const templatesStore = useTemplatesStore()

const isLoading = ref(false)
const existingOrder = ref(null)
const suggestedTemplate = ref(null)
const selectedTemplateId = ref('')
const selectedStatus = ref('0')
const issues = ref('')
const remarks = ref('')
const formResponses = ref({})

const availableTemplates = computed(() => {
  return templatesStore.templates?.filter(t => t.is_active !== false) || []
})

const getStatusColor = (status: number) => {
  switch (status) {
    case 1: return 'success'
    case 2: return 'warning'
    case 3: return 'danger'
    case 4: return 'dark'
    default: return 'medium'
  }
}

const getStatusLabel = (status: number) => {
  const labels: Record<number, string> = { 0:'To Do',1:'No Issues',2:'Remark',3:'Severe Issue',4:'Retired' }
  return labels[status] || 'Unknown'
}

const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString()

// --- Methods ---
const checkExistingOrder = async () => {
  if (!props.machine || !props.orderAddressId) return
  isLoading.value = true
  try {
    const existing = machineOrdersStore.machineOrders.find(
        o => o.machine?.id === props.machine.id && o.order_address_id === props.orderAddressId
    )
    if (existing) {
      existingOrder.value = existing
      selectedStatus.value = existing.status.toString()
      issues.value = existing.issues || ''
      remarks.value = existing.remarks || ''
      selectedTemplateId.value = existing.template?.id || ''
      if (existing.form_responses) {
        const responses: Record<string, any> = {}
        existing.form_responses.forEach(r => { responses[r.field_id] = r.response_data })
        formResponses.value = responses
      }
    } else {
      // Suggest latest template
      const lastTemplateOrder = machineOrdersStore.machineOrders
          .filter(o => o.machine?.id === props.machine.id && o.template)
          .pop()
      if (lastTemplateOrder) {
        const latestTemplate = availableTemplates.value.find(t =>
            t.id === lastTemplateOrder.template.id || t.parent_template_id === lastTemplateOrder.template.parent_template_id
        )
        if (latestTemplate) {
          suggestedTemplate.value = latestTemplate
          selectedTemplateId.value = latestTemplate.id
        }
      }
    }
  } catch (e) { console.error(e) }
  finally { isLoading.value = false }
}

const createMachineOrder = async () => {
  if (!props.machine || !props.orderAddressId) return
  isLoading.value = true
  try {
    const result = await machineOrdersStore.createMachineOrder({
      machine_id: props.machine.id,
      order_address_id: props.orderAddressId,
      template_id: selectedTemplateId.value || null,
      status: parseInt(selectedStatus.value),
    })
    const toast = await toastController.create({
      message: result.success ? 'Machine order created' : result.message || 'Failed',
      duration: 2000,
      color: result.success ? 'success':'danger',
    })
    await toast.present()
    if (result.success) emit('created')
  } catch (e) { console.error(e) }
  finally { isLoading.value = false }
}

const updateStatus = async () => {
  if (!existingOrder.value) return
  try {
    const result = await machineOrdersStore.updateMachineOrderStatus(existingOrder.value.id, {
      status: parseInt(selectedStatus.value),
      issues: issues.value,
      remarks: remarks.value,
    })
    const toast = await toastController.create({
      message: result.success ? 'Machine order updated' : result.message || 'Failed',
      duration: 2000,
      color: result.success ? 'success':'danger',
    })
    await toast.present()
    if (result.success) {
      existingOrder.value = { ...existingOrder.value, ...result.data.machine_order }
      emit('updated')
    }
  } catch (e) { console.error(e) }
}

const assignTemplate = async () => {
  if (!existingOrder.value) return
  try {
    const result = await machineOrdersStore.assignTemplate(existingOrder.value.id, selectedTemplateId.value || null)
    if (result.success) {
      existingOrder.value = await machineOrdersStore.fetchMachineOrderById(existingOrder.value.id)
      const toast = await toastController.create({ message: 'Template assigned', duration: 2000, color: 'success' })
      await toast.present()
      emit('updated')
    }
  } catch (e) { console.error(e) }
}

const saveFormResponses = async () => {
  const toast = await toastController.create({ message: 'Form responses saved', duration: 2000, color: 'success' })
  await toast.present()
}

// --- Watch modal open ---
watch(() => props.isOpen, async (isOpen) => {
  if (isOpen) await nextTick().then(checkExistingOrder)
  else {
    existingOrder.value = null
    suggestedTemplate.value = null
    selectedTemplateId.value = ''
    selectedStatus.value = '0'
    issues.value = ''
    remarks.value = ''
    formResponses.value = {}
  }
}, { immediate: true })

onMounted(async () => {
  await templatesStore.fetchTemplates()
  if (props.isOpen) await checkExistingOrder()
})
</script>

<style scoped>
.loading-container { display:flex; flex-direction:column; align-items:center; justify-content:center; padding:2rem; text-align:center; }
.detail-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:.5rem; }
.suggested-template { margin-bottom:1rem; border:1px solid var(--ion-color-warning); border-radius:8px; }
.form-section { margin-bottom:2rem; padding-bottom:1rem; border-bottom:1px solid var(--ion-color-light); }
.form-section h3 { margin:0 0 .5rem 0; color:var(--ion-color-primary); }
.form-field { margin-bottom:1rem; }
.required { color:var(--ion-color-danger); }
</style>
